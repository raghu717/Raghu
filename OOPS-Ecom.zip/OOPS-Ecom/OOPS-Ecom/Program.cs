﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS_Ecom
{
    class Program
    {
       
        static void Main(string[] args)
        {
           OrderList obj = new OrderList();
           obj.OlderOrderData(string.Empty);       
            Ecom eobj = new Ecom();
            Console.WriteLine("Enter Product Name");
            string productName = Console.ReadLine();
             string Available=string.Empty;
                Available = eobj.Check_Availabulity(productName);
                if (Available == "Available")
                {
                    Console.WriteLine("Enter No of Quantity");
                    int qty = int.Parse(Console.ReadLine());
                    Console.WriteLine("1.US\n2.Other then US");
                    Console.WriteLine("Enter Country Code");          
                    string country = Console.ReadLine();
                    string cName = obj.address(country);
                    Console.WriteLine("Given Items is:" + Available+"\n");
                    string CNAME = string.Empty;
                double price=    eobj.WareHouse_MenuItemsAvailable(productName);
                    if (cName == "Automatic Delivery")
                    {
                        obj.Take_Order(productName, qty, qty*price, "US");
                        Console.WriteLine("Automatic Delivered");
                    }
                    else
                    {
                        obj.Take_Order(productName, qty, qty * price, "Your Country Code :" + country);
                        Console.WriteLine("Delivered Processed!!");
                    }

                }
               else  if (Available == "Not Available")
                    Console.WriteLine("Product Is Not Available");
                    
             Console.ReadLine();
            } 
           
        }
     public class Ecom
    {
        Dictionary<int, string> items;
       static Dictionary<string, double> menuitems;
 
        public  double WareHouse_MenuItemsAvailable(string menu)  
        {
            menuitems = new Dictionary<string, double>();
            menuitems.Add("IPHONE 5S", 20000.00);
            menuitems.Add("IPHONE 6S", 30000.00);
            menuitems.Add("IPHONE 6S Plus", 60000.00);
            menuitems.Add("IPHONE 7S", 80000.00);
            double price;
            if (menuitems.TryGetValue(menu.ToUpper(), out price) == true)
            {
                return price;
            }
            return 0;
         
     
        }
        public string Check_Availabulity(string OrderItem)
        {
            double isValid;
            WareHouse_MenuItemsAvailable(string.Empty);
                 if (menuitems.TryGetValue(OrderItem.ToUpper(), out isValid) == true)
                 {
                     return "Available";
                 }
                 else return "Not Available";
        }
       
    }
     public class OrderList
     {
       public   List<int> Order_Id;
       public List<string> Order_Name;
       public List<double> Price;
 
         string item;
         int Quantity;
         double price;
         string Address;

         //public void Squere(int height,int width)
         //{
         //    for (int i = 1; i <= height; i++)
         //    {

         //        for (int j = 1; j <= width; j++)
         //        {

         //            if ((i == 1 || i == height) || (j == 1 || j == width))

         //                Console.Write("*"); //prints at border place

         //            else

         //                Console.Write(" "); //prints inside other than border

         //        }

         //        Console.WriteLine();

         //    }

         //}
         public void AddOldOrder()
         {
             List<OldOrder> old = new List<OldOrder>()
             {
                 new OldOrder{Id=1,Name="Iphone 5S",Quantity=200,Price=20000,Address="U S"},
                 new OldOrder{Id=1,Name="Iphone 6S",Quantity=20,Price=40000,Address="U S"},
                 new OldOrder{Id=1,Name="Iphone 7S",Quantity=100,Price=60000,Address="U S"},
                 new OldOrder{Id=1,Name="Iphone 10S",Quantity=50,Price=80000,Address="U S"},
             };
         

         }
         public void OlderOrderData(string Item)
         {
             string itemname = Item;
             List<int> OlderId=new List<int>();
             OlderId.Insert(0, 1);
             OlderId.Insert(1, 2);
             OlderId.Insert(2, 3);
             OlderId.Insert(3, 4);
             List<string> OlderName = new List<string>();
             OlderName.Insert(0, "Iphone 5S");
             OlderName.Insert(1, "Iphone 6S");
             OlderName.Insert(2, "Iphone 6S Plus");
             OlderName.Insert(3, "Iphone 7S ");
             List<int> Quantity = new List<int>();
             Quantity.Insert(0, 10);
             Quantity.Insert(1, 100);
             Quantity.Insert(2, 50);
             Quantity.Insert(3, 70);
             List<double> Price = new List<double>();
             Price.Insert(0, 20000.00);
             Price.Insert(1, 30000.00);
             Price.Insert(2, 40000.00);
             Price.Insert(3, 60000.00);
             Quantity.Sort();
             int greatestValue = Quantity[Quantity.Count - 1];
            // Console.WriteLine("Quantity:" + greatestValue + "\n");
             int heightindex = 0;
             var index = Quantity[Quantity.Count - 1];
             foreach (var rowObject in Quantity.Cast<object>().Select((r, i) => new { Row = r, Index = i }))
             {
                 var row = rowObject.Row;
                 var i = rowObject.Index;
                 if (i == 3)
                     heightindex = int.Parse(i.ToString());
             }
             Console.WriteLine("Highest Purchased Phones!!");

             Console.WriteLine("OrderId:" + OlderId[heightindex] + "\n" + "Order Name:" + OlderName[heightindex] + "\n" + "Quantity:" + Quantity[heightindex] + "\n" + "Price $:" + Price[heightindex] + "\n");
             for (int j = 0; j < OlderId.Count; j++)
             {

                 Console.WriteLine("OrderId:" + OlderId[j] + "\n" + "Order Name:" + OlderName[j] + "\n" + "Quantity:" + Quantity[j] + "\n"+"Price $:" + Price[j]+"\n");
                 
             }

             
         }
         //protected static int origRow;
         //protected static int origCol;

         //protected static void WriteAt(string s, int x, int y)
         //{
         //    try
         //    {
         //        Console.SetCursorPosition(origCol + x, origRow + y);
         //        Console.Write(s);
         //    }
         //    catch (ArgumentOutOfRangeException e)
         //    {
         //        Console.Clear();
         //        Console.WriteLine(e.Message);
         //    }
         //}

         public void Take_Order(string Item,int Quantity,double Money,string Address)
         {
             
            IEnumerable<Tuple<string, int, double,string>> authors =
           new[]
            {
              Tuple.Create(Item,Quantity,Money,Address),
            
            };
             Console.WriteLine(authors.ToStringTable(
          new[] { "Item", "Quantity", "Money", "Address" },
          a => Item, a => Quantity, a => Money, a => Address));
                // Console.WriteLine("Item Name:" + Item);
                //Console.WriteLine("Quantity :" + Quantity);
                //Console.WriteLine("Price:" + Money);
                //Console.WriteLine("Your Country Code :" + Address);
         }
         public string address(string Address) 
         {
             if (Address == "1")
                 return "Automatic Delivery";
             else
                 return "Can't be automatic processed";  
         }
        
     }

     

     public static class TableParser
     {
         public static string ToStringTable<T>(
           this IEnumerable<T> values,
           string[] columnHeaders,
           params Func<T, object>[] valueSelectors)
         {
             return ToStringTable(values.ToArray(), columnHeaders, valueSelectors);
         }

         public static string ToStringTable<T>(
           this T[] values,
           string[] columnHeaders,
           params Func<T, object>[] valueSelectors)
         {
             Debug.Assert(columnHeaders.Length == valueSelectors.Length);

             var arrValues = new string[values.Length + 1, valueSelectors.Length];

             // Fill headers
             for (int colIndex = 0; colIndex < arrValues.GetLength(1); colIndex++)
             {
                 arrValues[0, colIndex] = columnHeaders[colIndex];
             }

             // Fill table rows
             for (int rowIndex = 1; rowIndex < arrValues.GetLength(0); rowIndex++)
             {
                 for (int colIndex = 0; colIndex < arrValues.GetLength(1); colIndex++)
                 {
                     arrValues[rowIndex, colIndex] = valueSelectors[colIndex]
                       .Invoke(values[rowIndex - 1]).ToString();
                 }
             }

             return ToStringTable(arrValues);
         }

         public static string ToStringTable(this string[,] arrValues)
         {
             int[] maxColumnsWidth = GetMaxColumnsWidth(arrValues);
             var headerSpliter = new string('-', maxColumnsWidth.Sum(i => i + 3) - 1);

             var sb = new StringBuilder();
             for (int rowIndex = 0; rowIndex < arrValues.GetLength(0); rowIndex++)
             {
                 for (int colIndex = 0; colIndex < arrValues.GetLength(1); colIndex++)
                 {
                     // Print cell
                     string cell = arrValues[rowIndex, colIndex];
                     cell = cell.PadRight(maxColumnsWidth[colIndex]);
                     sb.Append(" | ");
                     sb.Append(cell);
                 }

                 // Print end of line
                 sb.Append(" | ");
                 sb.AppendLine();

                 // Print splitter
                 if (rowIndex == 0)
                 {
                     sb.AppendFormat(" |{0}| ", headerSpliter);
                     sb.AppendLine();
                 }
             }

             return sb.ToString();
         }

         private static int[] GetMaxColumnsWidth(string[,] arrValues)
         {
             var maxColumnsWidth = new int[arrValues.GetLength(1)];
             for (int colIndex = 0; colIndex < arrValues.GetLength(1); colIndex++)
             {
                 for (int rowIndex = 0; rowIndex < arrValues.GetLength(0); rowIndex++)
                 {
                     int newLength = arrValues[rowIndex, colIndex].Length;
                     int oldLength = maxColumnsWidth[colIndex];

                     if (newLength > oldLength)
                     {
                         maxColumnsWidth[colIndex] = newLength;
                     }
                 }
             }

             return maxColumnsWidth;
         }
     }

     public class OldOrder
     {
         public int Id { get; set; }
         public string Name { get; set; }
         public int Quantity { get; set; }
         public decimal Price { get; set; } 
         public string Address { get; set; }
     
     }
   
       
}
